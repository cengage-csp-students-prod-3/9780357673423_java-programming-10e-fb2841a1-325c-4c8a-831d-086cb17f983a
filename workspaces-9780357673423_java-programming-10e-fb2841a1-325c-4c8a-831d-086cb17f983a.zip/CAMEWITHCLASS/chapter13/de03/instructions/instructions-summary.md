## Instructions

The files provided in the code editor contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

```
Enter a character to find >> L
L is at position 2 in the array
Enter an integer to find >> 22
22 is at position 0 in the array
```
