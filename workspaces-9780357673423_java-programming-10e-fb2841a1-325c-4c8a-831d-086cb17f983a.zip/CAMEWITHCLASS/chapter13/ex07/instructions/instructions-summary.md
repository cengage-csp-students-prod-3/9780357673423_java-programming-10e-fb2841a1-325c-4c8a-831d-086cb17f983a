Write a program called `SwapAnyTypes` that prompts a user for two `String` values and two `int` values. Send the two `String` values to a generic method called `swap()` that sends them to another method called `display()`, swaps their values, and then sends them to the `display()` method again. Then send the two `int` values to the same method.

An example of the program is shown below: 
```
Enter a string >> Grover
Enter another string >> Rosanne
Enter an integer >> 719
Enter another integer >> 172
Grover Rosanne
Rosanne Grover
719 172
172 719
```

