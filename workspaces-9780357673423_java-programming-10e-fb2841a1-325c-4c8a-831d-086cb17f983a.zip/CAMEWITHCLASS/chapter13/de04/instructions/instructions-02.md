**Task 2:** The `DebugThirteen4` program accepts user input and displays the correct output.
