Write a program called `CommaPlacement` that creates a `String` `ArrayList`. Continually prompt the user for `String` values to add to the list until the user enters the sentinel value **ZZZ**. Using an `Iterator` display the `String` values in a single line separated by commas and ending with a period.

An example of the program is shown below: 
```
Enter a word or ZZZ to quit >> Kristofer
Enter another word or ZZZ to quit >> Mathilda
Enter another word or ZZZ to quit >> Chau
Enter another word or ZZZ to quit >> Jenette
Enter another word or ZZZ to quit >> Leighann
Enter another word or ZZZ to quit >> ZZZ
Kristofer, Mathilda, Chau, Jenette, Leighann.
```

