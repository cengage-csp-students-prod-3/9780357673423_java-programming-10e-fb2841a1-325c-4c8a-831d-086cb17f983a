**Task 2:** The `BonusBug13` program displays the correct playlists for the input provided.
