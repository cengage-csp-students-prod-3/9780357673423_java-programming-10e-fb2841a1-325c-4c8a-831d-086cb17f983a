**Task 1:** The `DebugTen3` class compiles without error.
