## Instructions

The files provided in the code editor contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

Examples of the program are shown below:

```
Enter a number to use in division
   and in accessing array >> 20
Result of division is 0
Index error - subscript out of range accessing array
```

```
Enter a number to use in division
   and in accessing array >> 2
Result of division is 6
Result accessing array is 6
Result of division is 2
Result accessing array is 6
Result of division is 3
Result accessing array is 6
Result of division is 4
Result accessing array is 6
```
