**Task 2:** The `DebugTen1` class catches any `Exception` from invalid input.
