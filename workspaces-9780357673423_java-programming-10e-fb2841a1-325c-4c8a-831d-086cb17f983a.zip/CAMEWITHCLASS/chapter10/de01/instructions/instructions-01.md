**Task 1:** The `DebugTen1` class compiles without error.
