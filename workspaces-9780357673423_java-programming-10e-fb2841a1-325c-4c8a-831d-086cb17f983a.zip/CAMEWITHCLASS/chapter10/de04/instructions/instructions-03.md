**Task 3:** The `DebugTen4` class catches any `Exception` thrown for invalid input.
