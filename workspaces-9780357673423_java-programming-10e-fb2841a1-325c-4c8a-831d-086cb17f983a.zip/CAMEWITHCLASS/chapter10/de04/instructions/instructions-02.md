**Task 2:** The `DebugTen4` class compiles without error.
