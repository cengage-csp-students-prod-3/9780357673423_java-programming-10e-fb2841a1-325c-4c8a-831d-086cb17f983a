**Task 1:** The `BonusBug10` class compiles without error.
