**Task 2:** The `BonusBug10` program catches any exceptions thrown and displays the exception information.
