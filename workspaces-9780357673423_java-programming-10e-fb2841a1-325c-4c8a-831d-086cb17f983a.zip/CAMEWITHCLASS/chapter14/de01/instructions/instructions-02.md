**Task 2:** The `DebugFourteen1` program accepts user input for the width and displays a `JFrame` twice as tall as wide.
