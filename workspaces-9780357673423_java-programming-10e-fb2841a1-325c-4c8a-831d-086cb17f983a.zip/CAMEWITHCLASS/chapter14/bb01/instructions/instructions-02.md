**Task 2:** The `BonusBug14` program contains a `JComboBox` with the correct selection options.
