From 1925 through 1963, Burma Shave advertising signs appeared next to highways across the United States. There were always four or five signs in a row containing pieces of a rhyme, followed by a final sign that read Burma Shave. For example, one set of signs that has been preserved by the Smithsonian Institution reads as follows:
```
Shaving brushes
You’ll soon see ’em
On a shelf
In some museum
Burma Shave
```
Find a classic Burma Shave rhyme on the Web, making sure the fifth line/sign is **Burma Shave**. Write, compile, and test a class called `BurmaShave` that displays the slogan.