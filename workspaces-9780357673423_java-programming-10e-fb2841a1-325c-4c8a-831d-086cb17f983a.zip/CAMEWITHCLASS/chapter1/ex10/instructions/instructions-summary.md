## Instructions
Write, compile, and test a class named `Comments` that displays the following statement about comments on two lines:

```
Program comments are nonexecuting statements 
you add to a file for documentation.
```

Also, include the same two line statement above using **three** different comment methods in the class.