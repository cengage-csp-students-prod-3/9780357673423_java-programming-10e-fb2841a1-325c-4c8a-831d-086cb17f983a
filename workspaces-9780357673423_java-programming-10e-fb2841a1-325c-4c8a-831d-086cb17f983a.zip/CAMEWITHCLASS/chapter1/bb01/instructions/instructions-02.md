**Task 2:** The `BonusBugO1` class contains comments.
