**Task 1:** The `BonusBug01` class compiles without error.
