**Task 2:** The `DebugTwo2` program accepts user input and displays the correct output.
