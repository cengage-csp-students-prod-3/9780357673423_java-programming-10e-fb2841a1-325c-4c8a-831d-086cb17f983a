import java.util.Scanner;
public class DebugTwo2
{
   public static void main(String args[])
   {
      int a, b;
      Scanner input = new Scanner(System.in);
      System.out.print("Enter an integer >> ");
      a = nextInt();
      System.out.print("Enter another integer >> ");
      b = nextInt();
      System.out.print1n("The sum is " + (a + b));
      System.out.println("The difference is " + (a - b));
      System.out.println("The product is " + (a * b));
   }
}