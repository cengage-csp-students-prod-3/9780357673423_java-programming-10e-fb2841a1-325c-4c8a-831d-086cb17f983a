**Task 2:** The `DebugTwo3` program accepts user input and displays the correct output.
