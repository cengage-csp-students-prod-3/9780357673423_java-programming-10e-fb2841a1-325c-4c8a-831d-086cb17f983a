## Instructions
The files provided in the code editor contains syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:
```
Enter an integer >> 11
Enter another integer >> 23
Divide 11 by 23
Result is 0
Remainder is 11
```