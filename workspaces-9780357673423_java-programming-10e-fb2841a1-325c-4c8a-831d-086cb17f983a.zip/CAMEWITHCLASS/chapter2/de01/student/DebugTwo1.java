import java.util.Scanner;
public class DebugTwo1
{
   public static void main(String[] args)
   {
      int oneInt;
      double oneDouble;
      String oneString;
      Scanner input = new Scanner(System.in);
      System.out.print("Enter an integer >> ");
      oneInt = input.nextLine();
      System.out.print("Enter a double >> ");
      oneDouble = input.nextLine();
      input.nextLine();
      System.out.print("Enter a string >> ");
      oneString = input.nextLine();
      System.out.print("The int is ");
      System.out.println(oneIntt);
      System.out.print(The double is ");
      System.out.println(oneDouble);
      System.out.print("The String is ");
      System.out.println(oneString);
   }
}