**Task 2:** The `DebugTwo1` program accepts user input and displays the correct output.
