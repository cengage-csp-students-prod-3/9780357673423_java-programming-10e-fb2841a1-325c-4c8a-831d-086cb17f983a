## Instructions

The files provided in the code editor contains syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

```
Enter an integer >> 11
Enter a double >> 83.23
Enter a string >> Java Programming
The int is 11
The double is 83.23
The String is Java Programming
```
