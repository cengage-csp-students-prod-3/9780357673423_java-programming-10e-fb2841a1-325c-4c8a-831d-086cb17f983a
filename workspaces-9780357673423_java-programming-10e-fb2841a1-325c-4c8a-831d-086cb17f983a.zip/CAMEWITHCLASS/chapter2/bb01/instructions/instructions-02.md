**Task 2:** The `BonusBug02` program accepts user input and displays the correct output.
