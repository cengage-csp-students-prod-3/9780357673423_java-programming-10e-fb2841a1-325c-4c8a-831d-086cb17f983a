Write a program called `IndirectRecursionDemo` that prompts the user for an integer. Pass the integer to a method called `method1` that determines whether the number is greater than 0; if it is, the method displays the number and passes one less than the parameter value to a second method. The second method, called `method2`, determines if the number passed in is greater than 0; if it is, the second method displays the number and passes one less than its parameter back to the first method.

An example of the program is shown below: 
```
Enter an integer >> 5
5 4 3 2 1
```

