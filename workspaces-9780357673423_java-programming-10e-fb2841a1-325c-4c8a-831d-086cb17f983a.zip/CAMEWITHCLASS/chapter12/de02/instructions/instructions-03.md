**Task 3:** The `DebugTwelve2` program accepts integer input and displays the sum of the numbers between the input value and the input value plus five.
