**Task 2:** The `DebugTwelve4` class contains the `display()` method.
