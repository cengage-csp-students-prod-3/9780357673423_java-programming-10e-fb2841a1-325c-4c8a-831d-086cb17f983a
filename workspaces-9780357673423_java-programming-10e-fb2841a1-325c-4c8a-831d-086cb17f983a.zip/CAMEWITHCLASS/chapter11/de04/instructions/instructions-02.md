**Task 2:** The `DebugEleven4` program reads entrees from the DebugData4.txt file.
