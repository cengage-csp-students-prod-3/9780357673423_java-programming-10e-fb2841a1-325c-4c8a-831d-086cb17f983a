## Instructions

The files provided in the code editor to the right contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

```
Enter maximum price to search for >> 20

Entrees no more than $20.0

steak  $20
macaroni  $8
spaghetti  $11
```
