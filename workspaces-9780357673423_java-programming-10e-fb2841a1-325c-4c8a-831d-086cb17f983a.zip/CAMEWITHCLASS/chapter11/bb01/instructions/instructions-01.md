**Task 1:** The `BonusBug11` class compiles without error.
