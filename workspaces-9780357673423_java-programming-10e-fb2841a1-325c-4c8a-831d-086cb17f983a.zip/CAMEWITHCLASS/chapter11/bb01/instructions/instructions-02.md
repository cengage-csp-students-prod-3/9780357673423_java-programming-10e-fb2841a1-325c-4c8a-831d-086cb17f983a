**Task 2:** The `BonusBug11` program displays the correct discount information.
