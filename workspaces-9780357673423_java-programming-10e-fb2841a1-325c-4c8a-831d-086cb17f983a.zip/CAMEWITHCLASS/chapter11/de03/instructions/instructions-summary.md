## Instructions

The files provided in the code editor to the right contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

```
Enter first entree or ZZZ to quit >> Ossobuco
Enter price >> 34.84
Enter next entree or ZZZ to quit >> Sirloin Tip Roast
Enter price >> 23.19
Enter next entree or ZZZ to quit >> ZZZ
```

```
Ossobuco,34.84
Sirloin Tip Roast,23.19
```

<sup>_DebugData4.txt_</sup>
