**Task 3:** The `DebugEleven1` program compares the two data files.
