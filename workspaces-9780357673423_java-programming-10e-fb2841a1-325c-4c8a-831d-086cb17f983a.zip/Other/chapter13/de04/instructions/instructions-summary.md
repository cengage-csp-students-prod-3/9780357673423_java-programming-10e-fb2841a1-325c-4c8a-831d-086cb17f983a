## Instructions

The files provided in the code editor contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

```
Enter ID number to add to the list or 999 to quit >> 978
Enter ID number to add to the list or 999 to quit >> 543
Enter ID number to add to the list or 999 to quit >> 894
Enter ID number to add to the list or 999 to quit >> 999
978  543  894
Enter an ID number to remove from the list >> 543
The revised list is:
978  894
```
