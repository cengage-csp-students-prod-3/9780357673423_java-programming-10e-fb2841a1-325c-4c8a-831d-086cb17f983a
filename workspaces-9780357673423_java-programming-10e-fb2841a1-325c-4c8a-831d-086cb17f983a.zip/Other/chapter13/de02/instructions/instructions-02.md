**Task 2:** The `DebugThirteen2` program accepts user input and displays the correct output.
