**Task 2:** The `DebugThirteen3` program accepts user input and displays the correct output.
