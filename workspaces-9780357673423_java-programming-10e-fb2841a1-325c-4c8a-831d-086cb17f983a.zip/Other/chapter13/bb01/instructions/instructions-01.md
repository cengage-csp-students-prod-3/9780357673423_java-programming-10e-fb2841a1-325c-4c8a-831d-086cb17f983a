**Task 1:** The `BonusBug13` class compiles without error.
