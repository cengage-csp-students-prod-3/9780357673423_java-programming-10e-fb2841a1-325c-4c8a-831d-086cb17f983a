Write a program called `RemoveNumber` that creates an `Integer` `ArrayList` and prompts the user for at least four integers and stores them in the `ArrayList`. Terminate the user input using the sentinel value **ZZZ**. Use an iterator to display all the numbers. Then prompt the user for a value to remove from the list. If the number appears in the list, remove it. Display the list again.

An example of the program is shown below: 
```
Enter integers or ZZZ to stop: 
14
12
3
4
8
4
ZZZ
Numbers:
14 12 3 4 8 4 
Enter a number to eliminate >> 3
Numbers:
14 12 4 8 4
```

