**Task 2:** The `DebugThirteen1` program accepts user input and displays the correct output.
