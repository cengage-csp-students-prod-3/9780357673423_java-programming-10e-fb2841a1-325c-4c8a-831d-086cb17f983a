**Task 3**: Cut and paste the code into the editor and run. Observe the output before moving on.
