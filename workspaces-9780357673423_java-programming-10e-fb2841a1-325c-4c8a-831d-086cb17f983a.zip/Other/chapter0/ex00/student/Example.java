// This is the code editor
public class Example {
    public static void main(String[] args) {
        System.out.println("This is the code editor.");
    }
}