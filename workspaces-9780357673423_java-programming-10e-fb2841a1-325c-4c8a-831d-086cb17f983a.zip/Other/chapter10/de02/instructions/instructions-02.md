**Task 2:** The `DebugTen2` class catches any `Exception` thrown for invalid input.
