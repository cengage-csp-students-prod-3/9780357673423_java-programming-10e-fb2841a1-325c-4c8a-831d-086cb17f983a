**Task 1:** The `DebugTen2` class compiles without error.
