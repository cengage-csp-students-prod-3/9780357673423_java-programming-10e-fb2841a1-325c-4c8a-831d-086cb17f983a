**Task 1:** The `DebugEmployeeIDException` class compiles without error.
