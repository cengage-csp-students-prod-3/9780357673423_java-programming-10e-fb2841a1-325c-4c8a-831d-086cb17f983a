public class DebugEmployeeIDException extends Exxception
{
   public DebugEmployeeIDException(String s)
   {
      super(s);
   }

