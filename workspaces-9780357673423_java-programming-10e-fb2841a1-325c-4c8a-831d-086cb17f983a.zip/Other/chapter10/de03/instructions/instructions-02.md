**Task 2:** The `DebugTen3` class catches any `Exception` thrown for invalid input.
