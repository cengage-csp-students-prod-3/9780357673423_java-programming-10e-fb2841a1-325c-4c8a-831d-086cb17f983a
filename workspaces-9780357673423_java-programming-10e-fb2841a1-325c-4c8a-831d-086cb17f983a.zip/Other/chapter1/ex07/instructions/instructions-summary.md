Write, compile, and test a class called `MovieQuoteInfo` that uses four `println()` statements to display, in order, your favorite movie quote, the movie it comes from, the character who said it, and the year of the movie.

An example of the program is shown below:
```
Rosebud,
said by Charles Foster Kane
in the movie Citizen Kane
in 1941.
```