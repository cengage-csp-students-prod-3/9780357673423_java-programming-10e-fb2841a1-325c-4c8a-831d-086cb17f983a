Write, compile, and test a class called `SongLyrics` that uses **four** `println()` statements to display four lines of the lyrics of your favorite song.

An example of the program is shown below: 
```
Somewhere over the rainbow
Way up high
There's a land that I heard of
Once in a lullaby
```