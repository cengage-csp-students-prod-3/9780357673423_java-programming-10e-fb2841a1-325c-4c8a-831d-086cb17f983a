**Task 01:**  Create the `Comments` class.
