/* File Name: BonusBug01.java
This is a debugging activity to learn the syntax of Java.
In this exercise, a welcome message for the guessing game is displayed as a console output.
//

public class BonusBug01
{
   public static void main(Strings[] args)
   {
system.Out.println("Welcome to the Guessing Game!!!")
  }
}
