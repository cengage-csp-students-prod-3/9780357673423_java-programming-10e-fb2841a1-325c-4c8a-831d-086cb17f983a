## Scenario
Let’s play the guessing game. In this game, the user will be asked to input any value from 1 to 100 (inclusive). In this exercise you will debug the program's  welcome message for the user.

## Instructions
This exercise will introduce the user to the guessing game using console output. Debug the syntax errors so that the Java application displays a welcome message and documents comments properly in the application. Debug the Java application to allow for a console output with comments. Remember this is only the welcome message portion of the program!

An example of the program is shown below:
```
Welcome to the Guessing Game!!!
```

