**Task 01:**  Create the `Triangle` class. 
