Write, compile, and test a class called `Triangle` that displays the art pattern shown below:

```
      T
     TTT
    TTTTT
   TTTTTTT
  TTTTTTTTT
 TTTTTTTTTTT
TTTTTTTTTTTTT
```
