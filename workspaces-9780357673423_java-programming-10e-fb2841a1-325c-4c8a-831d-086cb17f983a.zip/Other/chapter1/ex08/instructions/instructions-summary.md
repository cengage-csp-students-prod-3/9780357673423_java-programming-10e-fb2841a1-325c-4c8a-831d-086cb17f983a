# Instructions
Write, compile, and test a class named `TableAndChairs` that displays the art pattern shown below:

```
X                      X
X                      X
X      XXXXXXXXXX      X
XXXXX  X        X  XXXXX
X   X  X        X  X   X
X   X  X        X  X   X
```