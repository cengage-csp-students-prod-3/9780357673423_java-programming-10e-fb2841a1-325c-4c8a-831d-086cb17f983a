**Task 2:** The `DebugEleven2` program writes the area code provided as input to the phone numbers in a new file.
