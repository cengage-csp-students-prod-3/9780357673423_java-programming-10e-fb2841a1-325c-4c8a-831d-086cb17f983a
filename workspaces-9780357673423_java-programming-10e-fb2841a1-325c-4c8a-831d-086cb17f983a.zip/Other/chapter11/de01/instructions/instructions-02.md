**Task 2:** The `DebugEleven1` program displays file statistics.
