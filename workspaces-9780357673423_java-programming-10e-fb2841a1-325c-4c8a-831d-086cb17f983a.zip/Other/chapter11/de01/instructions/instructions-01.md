**Task 1:** The `DebugEleven1` class compiles without error.
