## Scenario
Let’s play the guessing game. In this game, the user will be asked to input any value from 1 to 100 (inclusive) and the Java application will display the guessed value.  

## Instructions
This exercise will ask the user to input a value from 1-100 (inclusive). Debug the syntax errors so that the Java application will allow the user to enter a value using the keyboard and display the entered value.

An example of the program is shown below: 
```
Welcome to the Guessing Game!!!!
Please enter your guessed number from 1 - 100:  23
Your guessed number is: 23
```