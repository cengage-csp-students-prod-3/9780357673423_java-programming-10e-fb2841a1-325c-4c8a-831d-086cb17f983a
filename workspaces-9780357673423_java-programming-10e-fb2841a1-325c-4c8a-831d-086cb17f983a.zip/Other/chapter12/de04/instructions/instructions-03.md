**Task 3:** The `DebugTwelve4` program displays the input word seven times.
