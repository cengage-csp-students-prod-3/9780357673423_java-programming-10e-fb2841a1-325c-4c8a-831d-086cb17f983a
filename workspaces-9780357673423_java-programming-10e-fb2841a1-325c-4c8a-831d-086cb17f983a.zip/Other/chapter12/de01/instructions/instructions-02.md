**Task 2:** The `DebugTwelve1` class contains the `repMethod()` method.
