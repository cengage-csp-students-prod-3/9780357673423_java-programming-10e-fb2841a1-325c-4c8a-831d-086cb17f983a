**Task 1:** The `DebugTwelve1` class compiles.
