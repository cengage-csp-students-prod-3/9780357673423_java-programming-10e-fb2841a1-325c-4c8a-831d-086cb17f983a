**Task 2:** The `DebugTwelve3` class contains the `display()` method.
