**Task 3:** The `DebugTwelve3` program displays the input word five times.
