**Task 2:** The `BonusBug12` program displays the correct pattern and number of **\*** for the input.
