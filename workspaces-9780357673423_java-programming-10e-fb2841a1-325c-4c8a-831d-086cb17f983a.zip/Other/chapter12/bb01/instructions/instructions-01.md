**Task 1:** The `BonusBug12` class compiles without error.
