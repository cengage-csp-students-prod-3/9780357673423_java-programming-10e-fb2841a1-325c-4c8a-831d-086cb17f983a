## Instructions

The files provided in the code editor contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:
![The G U I that is displayed when the Debug Fourteen 3 dot java program executes. The program allows a user to select toppings for a pizza from Paulo's American Pie. The program displays a J Frame that has a J Combobox with a list of pizza toppings. Once a topping has been selected, the total price of the pizza with the selected topping is displayed. For instance, if sausage topping is selected, the following is displayed. Pizza Price 10 dollars.](../assets/jG6wozmuRACozW8dNj26.png)
