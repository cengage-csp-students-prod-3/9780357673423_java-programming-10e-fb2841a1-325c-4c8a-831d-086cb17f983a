**Task 3:** The `DebugFourteen3` program displays the correct price for the topping selected.
