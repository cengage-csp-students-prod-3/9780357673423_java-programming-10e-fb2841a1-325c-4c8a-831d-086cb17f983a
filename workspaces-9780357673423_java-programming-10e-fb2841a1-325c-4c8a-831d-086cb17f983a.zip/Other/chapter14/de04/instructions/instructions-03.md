**Task 3:** The `DebugFourteen4` program displays the correct price for the beverage selected.
