## Instructions

The files provided in the code editor contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

![The G U I that is displayed when the Debug Fourteen 4 dot java program executes. The program allows a user to order beverages. Cola, Lemonade, Iced tea, Milk, or Coffee can be ordered. Cola and milk cost 3 dollars each while the other beverages cost 2 dollars. The program displays a J Frame with the beverages listed in checkboxes in a button group. Once a beverage is selected, the price is displayed. For instance, if lemonade is selected, the price displayed is 2 dollars.](../assets/kqqh3NDkSZOpRd6KYavu.png)
