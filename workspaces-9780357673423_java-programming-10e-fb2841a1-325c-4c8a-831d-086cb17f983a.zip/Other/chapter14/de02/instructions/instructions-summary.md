## Instructions

The files provided in the code editor contain syntax and/or logic errors. In each case, determine and fix the problem, remove all syntax and coding errors, and run the program to ensure it works properly.

An example of the program is shown below:

![The G U I that is displayed when the Debug Fourteen 2 dot java program executes. The program displays a J Frame that has a J Combobox with a list of payment methods. Once a payment method is selected, the payment charge for that method is displayed in percentage. If check is selected the following is displayed. 2 percent will be added to your bill.](../assets/5WsJdut0SB6u39dxS5aS.png)
