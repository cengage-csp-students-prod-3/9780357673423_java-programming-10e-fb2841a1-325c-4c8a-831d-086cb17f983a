**Task 1:** The `BonusBug14` class compiles without error.
